package br.com.avaliacao.api_telemetria.dto;

public class SetorResponseDTO(
        Integer id,
        String nome,
        String localizacao
) {
}
