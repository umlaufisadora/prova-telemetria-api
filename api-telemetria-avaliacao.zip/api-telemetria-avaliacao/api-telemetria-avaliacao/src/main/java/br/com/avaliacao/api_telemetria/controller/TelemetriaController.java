package br.com.avaliacao.api_telemetria.controller;

import br.com.avaliacao.api_telemetria.dto.TelemetriaRequestDTO;
import br.com.avaliacao.api_telemetria.dto.TelemetriaResponseDTO;
import br.com.avaliacao.api_telemetria.service.TelemetriaService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;

@RestController
@RequestMapping("/api/v1/telemetria")
public class TelemetriaController {
    private final TelemetriaService telemetriaService;

    public TelemetriaController(TelemetriaService telemetriaService) {
        this.telemetriaService = telemetriaService;
    }

    @GetMapping
    public ResponseEntity<Page<TelemetriaResponseDTO>> listarTodos(
            @PageableDefault(size = 20, sort = "dataHora", direction = Sort.Direction.DESC) Pageable pageable) {

        Page<TelemetriaResponseDTO> page = telemetriaService.listarTodos(pageable);
        return ResponseEntity.ok(page);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TelemetriaResponseDTO> buscarPorId(@PathVariable Long id) {
        TelemetriaResponseDTO dto = telemetriaService.buscarPorId(id);
        return ResponseEntity.ok(dto);
    }

    @GetMapping("/motor/{motorId}")
    public ResponseEntity<Page<TelemetriaResponseDTO>> listarPorMotor(
            @PathVariable Integer motorId,
            @PageableDefault(size = 20, sort = "dataHora") Pageable pageable) {
        return ResponseEntity.ok(telemetriaService.buscarPorMotor(motorId, pageable));
    }


    @PostMapping
    public ResponseEntity<TelemetriaResponseDTO> registrar(@RequestBody @Valid TelemetriaRequestDTO dto) {
        TelemetriaResponseDTO response = telemetriaService.registrar(dto);
        URI uri = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(response.id())
                .toUri();
        return ResponseEntity.created(uri).body(response);
    }

}
