package br.com.avaliacao.api_telemetria.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class MotorResponseDTO{
}
