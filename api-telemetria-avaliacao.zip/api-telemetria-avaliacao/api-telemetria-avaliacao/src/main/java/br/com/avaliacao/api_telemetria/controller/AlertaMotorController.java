package br.com.avaliacao.api_telemetria.controller;

import br.com.avaliacao.api_telemetria.dto.AlertaRequestDTO;
import br.com.avaliacao.api_telemetria.dto.AlertaResolucaoDTO;
import br.com.avaliacao.api_telemetria.dto.AlertaResponseDTO;
import br.com.avaliacao.api_telemetria.service.AlertaMotorService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;

@Controller
public class AlertaMotorController {
    private final AlertaMotorService alertaService;

    public AlertaMotorController(AlertaMotorService alertaService) {
        this.alertaService = alertaService;
    }

    @PostMapping
    public ResponseEntity<AlertaResponseDTO> criar(@RequestBody @Valid AlertaRequestDTO dto) {
        AlertaResponseDTO criado = alertaService.criar(dto);
        URI uri = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(criado.id())
                .toUri();
        return created(uri).body(criado);
    }

    @GetMapping
    public ResponseEntity<Page<AlertaResponseDTO>> listarTodos(
          (required = false) Boolean resolvido,
            @PageableDefault(size = 20, sort = "dataAlerta", direction = Sort.Direction.DESC) Pageable pageable) {

        Page<AlertaResponseDTO> page = (resolvido != null)
                ? alertaService.listarPorStatusResolucao(resolvido, pageable)
                : alertaService.listarTodos(pageable);

        return ResponseEntity.ok(page);
    }

    @GetMapping("/motor/{motorId}")
    public ResponseEntity<Page<AlertaResponseDTO>> buscarPorMotor(
           Integer motorId,
            @PageableDefault(size = 20, sort = "dataAlerta", direction = Sort.Direction.DESC) Pageable pageable) {
        return ResponseEntity.ok(alertaService.buscarPorMotor(motorId, pageable));
    }

    @PatchMapping("/{id}/resolucao")
    public ResponseEntity<AlertaResponseDTO> atualizarStatusResolucao(
            @PathVariable Integer id,
            @RequestBody @Valid AlertaResolucaoDTO dto) {
        return ResponseEntity.ok(alertaService.atualizarStatusResolucao(id, dto));
    }
}
