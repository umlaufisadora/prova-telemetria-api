package br.com.avaliacao.api_telemetria.config;

public class OpenApiConfig {
    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("API de Telemetria de Motores Industriais")
                        .version("v1")
                        .description("REST API para monitoramento, ingestão de dados e alertas de motores fabris.")
                        .contact(new Contact()
                                .name("Suporte Técnico")
                                .email("suporte@ctw.com")));
    }
}
